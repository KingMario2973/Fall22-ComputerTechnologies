## Pygame Game Library
## Made By Gregory Moulton

##   Create main system to run system for every game,           DONE
##   Create icons for main screen allowing easy selections      4/4
##   Add more games    Current: 4

import pygame, sys
import Games.PGLMineSweeper as PGLMineSweeper
import Games.PGLConnect4 as PGLConnect4
import Games.PGLMasterMind as PGLMasterMind
import Games.PGLCheckers as PGLCheckers

def setUp():
    screen = pygame.display.set_mode([w,h])
    pygame.display.set_caption("Pygame Game Library")
    screen.fill([0, 0, 0])
    PGLMineSweeper.drawIcon(screen,50,75)
    PGLConnect4.drawIcon(screen,325,75)
    PGLMasterMind.drawIcon(screen,50,350)
    PGLCheckers.drawIcon(screen,325,350)
    pygame.display.flip()
    return 0

def iconClick(x,y):
    if abs(x-175) <= 125:
        x = 1
    elif abs(x-450) <= 125:
        x = 2
    else:
        return 0
    if abs(y-200) <= 125:
        return x
    elif abs(y-475) <= 125:
        return x+2
    return 0

w = 625
h = 675
game = 0

pygame.init()
screen = pygame.display.set_mode([w,h])
setUp()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.display.quit()
            sys.exit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            pos = list(pygame.mouse.get_pos())
            if pygame.mouse.get_pressed() == (1, 0, 0):
                game = iconClick(pos[0],pos[1])
    if game == 1 and PGLMineSweeper.run():
        game = setUp()
    elif game == 2 and PGLConnect4.run():
        game = setUp()
    elif game == 3 and PGLMasterMind.run():
        game = setUp()
    elif game == 4 and PGLCheckers.run():
        game = setUp()
