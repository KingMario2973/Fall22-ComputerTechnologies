## MasterMind in python
## Made By Gregory Moulton

import random, sys, pygame

pygame.init()
screen = pygame.display.set_mode([625,675])
size=625/10
colors = ['B','Y','K','W','R','G','<']

def printGame(screen,gLog,cGuess):
    screen.fill([160, 160, 160])
    pygame.draw.rect(screen, [255,0,0], [0,0, 625, 50])
    pygame.draw.rect(screen, [0,0,0], [0,50, 625, 5])
    pygame.draw.rect(screen, [0,0,0], [3*size-12,5.5*size+88, 4*size+24, size+24])
    pygame.draw.rect(screen, [0,120,0], [3*size-10,5.5*size+90, 4*size+20, size+20])
    pygame.draw.rect(screen, [0,0,0], [1.5*size-12,7.5*size+88, 7*size+24, size+24])
    pygame.draw.rect(screen, [255,120,120], [1.5*size-10,7.5*size+90, 7*size+20, size+20])
    for i in range(len(gLog)):
        for x in range(4):
            drawTile(screen,(i//5*6+x)*size,i%5*size+100,gLog[i][x],size)
        c=0
        for x in range(gLog[i][4]):
            drawTile(screen,(i//5+4+.5*(c%2))*size,(i%5+.5*(c//2)-.25)*size+100,'k',size)
            c+=1
        for x in range(gLog[i][5]):
            drawTile(screen,(i//5+4+.5*(c%2))*size,(i%5+.5*(c//2)-.25)*size+100,'w',size)
            c+=1
    for x in range(len(cGuess)):
            drawTile(screen,(3+x)*size,6*size+100,cGuess[x],size)
    for x in range(7):
            drawTile(screen,(1.5+x)*size,8*size+100,colors[x],size)            
    pygame.display.flip()

def drawTile(screen,x,y,tile,s):
    if tile =='k':
        pygame.draw.circle(screen, [0,0,0], [x+s/4,y], s/4.1+2)
    elif tile=='w':
        pygame.draw.circle(screen, [0,0,0], [x+s/4,y], s/4.1+2)
        pygame.draw.circle(screen, [255,255,255], [x+s/4,y], s/4)
    else:
        pygame.draw.circle(screen, [0,0,0], [x+s/2,y], s/2.1+2)
    if tile == 'B':
        pygame.draw.circle(screen, [0,0,255], [x+s/2,y], s/2.1)
    elif tile == 'Y':
        pygame.draw.circle(screen, [255,255,0], [x+s/2,y], s/2.1)
    elif tile == 'K':
        pygame.draw.circle(screen, [0,0,0], [x+s/2,y], s/2.1)
    elif tile == 'W':
        pygame.draw.circle(screen, [255,255,255], [x+s/2,y], s/2.1)
    elif tile == 'R':
        pygame.draw.circle(screen, [255,0,0], [x+s/2,y], s/2.1)
    elif tile == 'G':
        pygame.draw.circle(screen, [0,180,0], [x+s/2,y], s/2.1)
    elif tile == '<':
        pygame.draw.circle(screen, [200,120,0], [x+s/2,y], s/2.1)
        pygame.draw.polygon(screen, [0,0,0],[(x+s/1.5,y+s/3),(x+s/6,y),(x+s/1.5,y-s/3)])

def calcCode(guess,code):
    tcode=[code[0],code[1],code[2],code[3]]
    tguess=[guess[0],guess[1],guess[2],guess[3]]
    k = 0
    w = 0
    for x in range(4):
        if tguess[x]==tcode[x]:
            tcode[x]='k'
            tguess[x]='K'
            k+=1
    for x in range(4):
        if tguess[x] in tcode:
            tcode[tcode.index(tguess[x])]='w'
            tguess[x]='W'
            w+=1
    guess.append(k)
    guess.append(w)

def run():
    gLog = []
    code = []
    guess = []
    while len(code)<4:
        code.append(colors[random.randint(0,5)])
    pygame.display.set_caption("MasterMind")
    running=True
    while running and len(gLog)<10:
        printGame(screen,gLog,guess)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.display.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = list(pygame.mouse.get_pos())
                z = (pos[0]-(size*.5))
                z = int(z/size)-1
                if pos[1]<50:
                    return True
                if pygame.mouse.get_pressed() == (1, 0, 0):
                    if pos[1]>7.5*size+100 and pos[1]<8.5*size+100:
                        if z in range(0,7):
                            if z != 6:
                                if len(guess)==4:
                                    if guess==code:
                                        running=False
                                    calcCode(guess,code)
                                    gLog.append(guess)
                                    guess=[]
                                else:
                                    guess.append(colors[z])
                            elif len(guess)>0:
                                guess.pop()
                    
    printGame(screen,gLog,code)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.display.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if pygame.mouse.get_pressed() == (1, 0, 0):
                    pos = list(pygame.mouse.get_pos())
                    if pos[1]<50:
                        return True
                    return False

def drawIcon(screen,x,y):
    pygame.draw.rect(screen,[160, 160, 160],[x,y,250,250])
    code = []
    glist = []
    while len(code)<4:
        code.append(colors[random.randint(0,5)])
    for i in range(4):
        glist.append([])
        while len(glist[i])<4:
            glist[i].append(colors[random.randint(0,5)])
        calcCode(glist[i],code)
    for n in range(4):
        for m in range(4):
            drawTile(screen,x+m*50,y+n*50+25,glist[n][m],50)
        c=0
        for z in range(glist[n][4]):
            drawTile(screen,(4+.5*(c%2))*50+x,(n+.5*(c//2)-.25)*50+25+y,'k',50)
            c+=1
        for z in range(glist[n][5]):
            drawTile(screen,(4+.5*(c%2))*50+x,(n+.5*(c//2)-.25)*50+25+y,'w',50)
            c+=1
    for h in range(4):
        drawTile(screen,x+h*50+25,y+4.5*50,code[h],50)
    
    
    

