## Minesweeper in python
## Made By Gregory Moulton

import random, sys, pygame

pygame.init()
w = 25 #Number of columns
h = 25 #Number of rows
screen = pygame.display.set_mode([w*25,(h+2)*25])

def finalBoard(board,ground):
    fBoard=[]
    for item in ground:
        fBoard.append(item)
    for i in range(len(board)):
        if board[i]=='X':
            if fBoard[i]!='*' and fBoard[i]!='X':
                fBoard[i]='x'
        if fBoard[i]=='*':
            if board[i]!='X':
                fBoard[i]='$'
    return fBoard

def checkBorder(x,y,width,height):
    if y == 0:
        if not(x-width-1 < 0) and x%width != 0:
            return (True, x-width-1)
    if y == 1:
        if not(x-width < 0):
            return (True, x-width)
    if y == 2:
        if not(x-width+1 < 0) and x%width != width-1:
            return (True, x-width+1)
    if y == 3:
        if not(x-1 < 0) and x%width != 0:
            return (True, x-1)
    if y == 4:
        if x+1 < width*height and x%width != width-1:
            return (True, x+1)
    if y == 5:
        if x+width-1 < width*height and x%width != 0:
            return (True, x+width-1)
    if y == 6:
        if x+width < width*height:
            return (True, x+width)
    if y == 7:
        if x+width+1 < width*height and x%width != width-1:
            return (True, x+width+1)
    return (False, x)

def checkWin(ground,board):
    Cboard = ground[0:]
    for x in range(len(Cboard)):
        if Cboard[x]=='*':
            Cboard[x] = 'X'
    return (Cboard == board)

def setup(width, height, mines):
    mines = round(width*height*(mines/100))
    Sboard= []
    for x in range(width*height):
        if len(Sboard) <= mines:
            Sboard.append('X')
        else:
            Sboard.append('O')
    random.shuffle(Sboard)
    for x in range(len(Sboard)):
        if Sboard[x] != 'X':
            count = 0
            for y in range(8): #Create Numbers
                cBool,z = checkBorder(x,y,width,height)
                if cBool:
                    if Sboard[z] == 'X':
                        count += 1
            Sboard[x] = count
    return(Sboard)

def printBoard(Pboard,width,height):
    for y in range(height):
        for x in range(width):
            drawTile(x*25,(y+2)*25,Pboard[y*width+x],screen)
    pygame.draw.rect(screen, [255,0,0], [0,0, 625, 50])
    pygame.draw.rect(screen, [0,0,0], [0,50, 625, 5])
    pygame.display.flip()

def drawTile(x,y,tile,screen):
    if tile == '#':
        pygame.draw.rect(screen, [0,0,0], [x,y, 25, 25])
        pygame.draw.rect(screen, [150,150,150], [x+2,y+2, 21, 21])
    elif tile == '*': #Flag
        pygame.draw.rect(screen, [0,0,0], [x,y, 25, 25])
        pygame.draw.rect(screen, [200,150,150], [x+2,y+2, 21, 21])
        pygame.draw.line(screen, [255,0,0], [x+5,y+5],[x+20,y+10])
        pygame.draw.line(screen, [255,0,0], [x+20,y+10],[x+5,y+15])
        pygame.draw.line(screen, [0,0,0], [x+5,y+5],[x+5,y+20])
    elif tile=='X': #Dug mine
        pygame.draw.rect(screen, [200,50,50], [x,y, 25, 25])
        pygame.draw.polygon(screen, [0,0,0], [(x+25/2,y+6),(x+17,y+9),(x+17,y+15),(x+25/2,y+18),(x+6,y+15),(x+6,y+9)])
    elif tile=='x': #Unflagged Mine
        pygame.draw.rect(screen, [200,150,150], [x,y, 25, 25])
        pygame.draw.polygon(screen, [0,0,0], [(x+25/2,y+6),(x+17,y+9),(x+17,y+15),(x+25/2,y+18),(x+6,y+15),(x+6,y+9)])
    elif tile=='$': #Flagged NonMine
        pygame.draw.rect(screen, [0,0,0], [x,y, 25, 25])
        pygame.draw.rect(screen, [200,150,150], [x+2,y+2, 21, 21])
        pygame.draw.line(screen, [255,0,0], [x+5,y+5],[x+20,y+10])
        pygame.draw.line(screen, [255,0,0], [x+20,y+10],[x+5,y+15])
        pygame.draw.line(screen, [0,0,0], [x+5,y+5],[x+5,y+20])
        pygame.draw.line(screen, [255,0,0], [x+25,y],[x,y+25],3)
        pygame.draw.line(screen, [255,0,0], [x,y],[x+25,y+25],3)
    elif tile == 0:
        pygame.draw.rect(screen, [150,150,150], [x,y, 25, 25])
    elif tile == 1:
        pygame.draw.rect(screen, [150,150,180], [x,y, 25, 25])
        pygame.draw.line(screen, [0,0,255], [x+8,y+8],[x+25/2,y+5])
        pygame.draw.line(screen, [0,0,255], [x+25/2,y+5],[x+25/2,y+20])
        pygame.draw.line(screen, [0,0,255], [x+5,y+20],[x+18,y+20])
    elif tile == 2:
        pygame.draw.rect(screen, [150,170,150], [x,y, 25, 25])
        pygame.draw.line(screen, [0,255,0], [x+5,y+10],[x+25/2,y+5])
        pygame.draw.line(screen, [0,255,0], [x+20,y+10],[x+25/2,y+5])
        pygame.draw.line(screen, [0,255,0], [x+20,y+10],[x+5,y+20])
        pygame.draw.line(screen, [0,255,0], [x+20,y+20],[x+5,y+20])
    elif tile == 3:
        pygame.draw.rect(screen, [170,140,170], [x,y, 25, 25])
        pygame.draw.line(screen, [255,0,255], [x+8,y+5],[x+17,y+9])
        pygame.draw.line(screen, [255,0,255], [x+8,y+25/2],[x+17,y+9])
        pygame.draw.line(screen, [255,0,255], [x+8,y+25/2],[x+17,y+16])
        pygame.draw.line(screen, [255,0,255], [x+8,y+20],[x+17,y+16])
    elif tile == 4:
        pygame.draw.rect(screen, [190,170,150], [x,y, 25, 25])
        pygame.draw.line(screen, [255,125,0], [x+8,y+5],[x+8,y+25/2])
        pygame.draw.line(screen, [255,125,0], [x+8,y+25/2],[x+17,y+25/2])
        pygame.draw.line(screen, [255,125,0], [x+17,y+5],[x+17,y+20])
    elif tile == 5:
        pygame.draw.rect(screen, [180,180,150], [x,y, 25, 25])
        pygame.draw.line(screen, [220,220,0], [x+17,y+5],[x+8,y+5])
        pygame.draw.line(screen, [220,220,0], [x+8,y+5],[x+8,y+25/2])
        pygame.draw.line(screen, [220,220,0], [x+8,y+25/2],[x+17,y+16])
        pygame.draw.line(screen, [220,220,0], [x+8,y+20],[x+17,y+16])
    elif tile == 6:
        pygame.draw.rect(screen, [140,140,200], [x,y, 25, 25])
        pygame.draw.line(screen, [60,190,255], [x+8,y+5],[x+8,y+20])
        pygame.draw.line(screen, [60,190,225], [x+8,y+20],[x+17,y+20])
        pygame.draw.line(screen, [60,190,225], [x+17,y+20],[x+17,y+25/2])
        pygame.draw.line(screen, [60,190,225], [x+17,y+25/2],[x+8,y+25/2])
    elif tile == 7:
        pygame.draw.rect(screen, [150,150,150], [x,y, 25, 25])
        pygame.draw.line(screen, [0,0,0], [x+8,y+5],[x+17,y+5])
        pygame.draw.line(screen, [0,0,0], [x+17,y+5],[x+25/2,y+20])
    elif tile == 8:
        pygame.draw.rect(screen, [120,120,120], [x,y, 25, 25])
        pygame.draw.line(screen, [0,0,0], [x+25/2,y+5],[x+7.5,y+8.75])
        pygame.draw.line(screen, [0,0,0], [x+7.5,y+8.75],[x+17.5,y+16.25])
        pygame.draw.line(screen, [0,0,0], [x+17.5,y+16.25],[x+25/2,y+20])
        pygame.draw.line(screen, [0,0,0], [x+25/2,y+20],[x+7.5,y+16.25])
        pygame.draw.line(screen, [0,0,0], [x+7.5,y+16.25],[x+17.5,y+8.75])
        pygame.draw.line(screen, [0,0,0], [x+17.5,y+8.75],[x+25/2,y+5])
        
    elif tile == '?':
        pygame.draw.rect(screen, [0,0,0], [x,y, 25, 25])
        pygame.draw.rect(screen, [150,150,150], [x+2,y+2, 21, 21])
        pygame.draw.line(screen, [0,0,0], [x+25/2,y+21],[x+25/2,y+19])
        pygame.draw.line(screen, [0,0,0], [x+25/2,y+17],[x+25/2,y+15])
        pygame.draw.line(screen, [0,0,0], [x+25/2,y+15],[x+18,y+10])
        pygame.draw.line(screen, [0,0,0], [x+25/2,y+5],[x+18,y+10])
        pygame.draw.line(screen, [0,0,0], [x+25/2,y+5],[x+7,y+10])
    else:
        pygame.draw.rect(screen, [150,150,150], [x,y, 25, 25])

def digTile(ground,board,z,mode,I):
    if mode == 'D' and ground[z] != '*':
        ground[z]= board[z]
        if board[z] == 0 or I == 1: #Dig Nearby Tiles
            for v in range(8):
                cBool,u = checkBorder(z,v,w,h)
                if cBool:
                    if ground[u]=='#':
                        ground = digTile(ground,board,u,'D',0)
    elif mode == 'F':
        if ground[z] == '#':
            ground[z] = '*'
        elif ground[z] == '*':
            ground[z] = '?'
        elif ground[z] == '?':
            ground[z] = '#'
        if I == 1: #Flag Nearby Tiles
            for v in range(8):
                cBool,u = checkBorder(z,v,w,h)
                if cBool:
                    if ground[u]=='#':
                        ground = digTile(ground,board,u,'F',0)
    return ground

def run():
    board = []
    ground = []
    pygame.display.set_mode([w*25,(h+2)*25])
    pygame.display.set_caption("MineSweeper")
    screen.fill([255, 100, 100])
    board = setup(w,h,25)
    for square in board:
        ground.append('#')
    printBoard(ground,w,h)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.display.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = list(pygame.mouse.get_pos())
                row = pos[1]//25-2
                col = pos[0]//25
                if pygame.mouse.get_pressed() == (1, 0, 0):
                    if row<0:
                        return True
                    z = (col+(row)*h)
                    running = False
                    
    while board[z] != 0:
        board = setup(w,h,22) ## 22% of the board becomes a mine 
    printBoard(ground,w,h)
    ground = digTile(ground,board,z,'D',0)
    running = True
    while 'X' not in ground:
        printBoard(ground,w,h)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.display.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = list(pygame.mouse.get_pos())
                row = pos[1]//25-2
                col = pos[0]//25
                pos = col+(row)*h
                if row<0:
                    return True
                if pygame.mouse.get_pressed() == (1, 0, 0):
                    if ground[pos]=='#' or ground[pos]=='*' or ground[pos]=='?':
                        ground = digTile(ground,board,pos,'D',0)
                    else:
                        ground = digTile(ground,board,pos,'D',1)
                elif pygame.mouse.get_pressed() == (0, 0, 1):
                    if ground[pos]=='#' or ground[pos]=='*' or ground[pos]=='?':
                        ground = digTile(ground,board,pos,'F',0)
                    else:
                        ground = digTile(ground,board,pos,'F',1)
        if checkWin(ground,board):
            break
    printBoard(finalBoard(board,ground),w,h)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.display.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if pygame.mouse.get_pressed() == (1, 0, 0):
                    pos = list(pygame.mouse.get_pos())
                    row = pos[1]//25-2
                    if row<0:
                        return True
                    return False

def drawIcon(screen,x,y):
    icon = setup(12,12,25)
    for a in range(144):
        if icon[a] == 'X':
            icon[a]='*'
    for h in range(10):
        for n in range(10):
            drawTile(x+25*h,y+25*n,icon[n*12+h+13],screen)
