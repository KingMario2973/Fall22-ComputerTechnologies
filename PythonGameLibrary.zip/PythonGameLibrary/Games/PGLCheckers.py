## Checkers in python
## Made By Gregory Moulton

import sys, pygame

pygame.init()
screen = pygame.display.set_mode([625,675])

size=625/8

def printBoard(screen,Pboard,s,player):
    screen.fill([250, 250, 20])
    for y in range(8):
        for x in range(8):
            if (x+y)%2==0:
                pygame.draw.rect(screen, [255,255,255], [x*size,y*size+50, size, size])
            else:
                pygame.draw.rect(screen, [0,0,0], [x*size,y*size+50, size, size])
    if s[1]!=-1:       
        pygame.draw.rect(screen, [180,255,150], [s[1][1]*size-10,s[1][0]*size+40, size+20, size+20])
        if (s[1][1]+s[1][0])%2==0:
            pygame.draw.rect(screen, [255,255,255], [s[1][1]*size,s[1][0]*size+50, size, size])
        else:
            pygame.draw.rect(screen, [0,0,0], [s[1][1]*size,s[1][0]*size+50, size, size])
    if s[0]!=-1:
        if player == 'R':
            pygame.draw.rect(screen, [255,0,0], [s[0][1]*size-10,s[0][0]*size+40, size+20, size+20])
        else:
            pygame.draw.rect(screen, [0,0,255], [s[0][1]*size-10,s[0][0]*size+40, size+20, size+20])
        if (s[0][1]+s[0][0])%2==0:
            pygame.draw.rect(screen, [255,255,255], [s[0][1]*size,s[0][0]*size+50, size, size])
        else:
            pygame.draw.rect(screen, [0,0,0], [s[0][1]*size,s[0][0]*size+50, size, size])
    for y in range(8):
        for x in range(8):
            drawTile(x*size,y*size+50,Pboard[y][x],size,screen)
    pygame.draw.rect(screen, [255,0,0], [0,0, 625, 50])
    pygame.draw.rect(screen, [0,0,0], [0,50, 625, 5])
    pygame.display.flip()

def drawTile(x,y,tile,s,screen):
    if tile == 'R':     #Red Tile
        pygame.draw.circle(screen, [255,0,0], [x+s/2,y+s/2], s/2.2)
    elif tile == 'B':   #Blue Tile
        pygame.draw.circle(screen, [0,0,255], [x+s/2,y+s/2], s/2.2)
    if tile == 'R*':     #Red King
        pygame.draw.circle(screen, [255,0,0], [x+s/2,y+s/2], s/2.2)
        pygame.draw.circle(screen, [255,255,0], [x+s/2,y+s/2], s/4)
    elif tile == 'B*':   #Blue King
        pygame.draw.circle(screen, [0,0,255], [x+s/2,y+s/2], s/2.2)
        pygame.draw.circle(screen, [255,255,0], [x+s/2,y+s/2], s/4)

def checkWin(board):
    r=False
    b=False
    for y in range(8):
        for x in range(8):
            if not(r) and board[y][x] in ['R','R*']:
                r = True
            elif not(b) and board[y][x] in ['B','B*']:
                b = True
    return r and b

def move(board,s,player):
    sc=s[1]
    sn=s[0]
    if sc == -1 or sc[0]==-1 or sn[1]==-1:
        return player,s
    if board[sc[0]][sc[1]] in ['R','R*']:
        tiles = ['B','B*']
    else:
        tiles = ['R','R*']
    if (sn[0]+sn[1])%2==0 or board[sn[0]][sn[1]]!='#':
        return player,s
    if board[sc[0]][sc[1]]=='R':
        if sc[0]+1!=sn[0]:
            if sc[0]+2!=sn[0]:
                return player,s
            elif sc[1]-2==sn[1] and board[sc[0]+1][sc[1]-1] in tiles:
                board[sc[0]+1][sc[1]-1]='#'
            elif sc[1]+2==sn[1] and board[sc[0]+1][sc[1]+1] in tiles:
                board[sc[0]+1][sc[1]+1]='#'
            else:
                return player,s
        elif sc[1]-1!=sn[1] and sc[1]+1!=sn[1]:
            return player,s    
    elif board[sc[0]][sc[1]]=='B':
        if sc[0]-1!=sn[0]:
            if sc[0]-2!=sn[0]:
                return player,s
            elif sc[1]-2==sn[1] and board[sc[0]-1][sc[1]-1] in tiles:
                board[sc[0]-1][sc[1]-1]='#'
            elif sc[1]+2==sn[1] and board[sc[0]-1][sc[1]+1] in tiles:
                board[sc[0]-1][sc[1]+1]='#'
            else:
                return player,s
        elif sc[1]-1!=sn[1] and sc[1]+1!=sn[1]:
            return player,s  
    else:
        if sc[0]+1==sn[0] or sc[0]-1==sn[0]:
            if sc[1]-1!=sn[1] and sc[1]+1!=sn[1]:
                return player,s
        elif sc[0]+2==sn[0]:
            if sc[1]-2==sn[1] and board[sc[0]+1][sc[1]-1] in tiles:
                board[sc[0]+1][sc[1]-1]='#'
            elif sc[1]+2==sn[1] and board[sc[0]+1][sc[1]+1] in tiles:
                board[sc[0]+1][sc[1]+1]='#'
            else:
                return player,s
        elif sc[0]-2==sn[0]:
            if sc[1]-2==sn[1] and board[sc[0]-1][sc[1]-1] in tiles:
                board[sc[0]-1][sc[1]-1]='#'
            elif sc[1]+2==sn[1] and board[sc[0]-1][sc[1]+1] in tiles:
                board[sc[0]-1][sc[1]+1]='#'
            else:
                return player,s
        else:
            return player,s  
    
    board[sn[0]][sn[1]]=board[sc[0]][sc[1]]
    if board[sn[0]][sn[1]]=='R' and sn[0]==7:
        board[sn[0]][sn[1]] = 'R*'
    if board[sn[0]][sn[1]]=='B' and sn[0]==0:
        board[sn[0]][sn[1]] = 'B*'
    board[sc[0]][sc[1]]='#'
    s=[-1,-1]
    if player=='R':
        return 'B',s
    return 'R',s

def run():
    board = []
    pygame.display.set_mode([625,675])
    pygame.display.set_caption("Checkers")
    player = 'R'
    selected=[-1,-1]
    for n in range(8):
        board.append([])
        for z in range(8):
            if (n+z)%2==1:
                if n<3:
                    board[n].append('R')
                elif n>4:
                    board[n].append('B')
                else:
                    board[n].append('#')
            else:
                board[n].append(' ')
    while checkWin(board):
        printBoard(screen,board,selected,player)
        pos = list(pygame.mouse.get_pos())
        col = int(pos[0]/size)
        row = int((pos[1]-50)/size)
        selected[0]=(row,col)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.display.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if pos[1]<=50:
                    return True
                if pygame.mouse.get_pressed() == (1, 0, 0):
                    if board[row][col]==player or board[row][col]==player+'*':
                        selected[1]=(row,col)
                    player,selected = move(board,selected,player)
                   
    printBoard(screen, board,[-1,-1],'')
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.display.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if pygame.mouse.get_pressed() == (1, 0, 0):
                    pos = list(pygame.mouse.get_pos())
                    if pos[1]<=50:
                        return True
                    return False

def drawIcon(screen,x,y):
    board=[]
    for n in range(8):
        board.append([])
        for z in range(8):
            if (n+z)%2==0:
                if n<3:
                    board[n].append('R')
                elif n>4:
                    board[n].append('B')
                else:
                    board[n].append('#')
            else:
                board[n].append(' ')
    for n in range(8):
        for m in range(8):
            if (n+m)%2==1:
                pygame.draw.rect(screen, [255,255,255], [x+m*250/8,y+n*250/8, 250/8, 250/8])
            else:
                pygame.draw.rect(screen, [0,0,0], [x+m*250/8,y+n*250/8, 250/8, 250/8])
    for n in range(8):
        for m in range(8):
            drawTile(m*250/8+x,n*250/8+y,board[n][m],250/8,screen)


