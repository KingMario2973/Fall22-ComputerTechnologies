## Connect 4 in python
## Made By Gregory Moulton

## add turn based system to add tiles,                              DONE
## use mouse posision to show where and what tiles will be placed   DONE
## Finish method to check valid tile, then add tile to board        DONE
## Make end screen draw a line between every valid 4 in a row       DONE

import sys, pygame, random

pygame.init()
screen = pygame.display.set_mode([625,675])

size=625/7

def checkWin(board,rBool):
    coords = []
    if '#' not in board:
        if rBool:
            return True
        return coords
    for x in range(4):   ## Horizontal
        for y in range(6):
            if board[x+y*7] != '#' and board[x+y*7]==board[x+y*7+1] and board[x+y*7]==board[x+y*7+2] and board[x+y*7]==board[x+y*7+3]:
                if rBool:
                    return True
                coords.append(((x+.5)*size,675-((y+.5)*size)))
                coords.append(((x+3.5)*size,675-((y+.5)*size)))
    for x in range(7):   ## Vertical
        for y in range(3):
            if board[x+y*7] != '#' and board[x+y*7]==board[x+y*7+7] and board[x+y*7]==board[x+y*7+14] and board[x+y*7]==board[x+y*7+21]:
                if rBool:
                    return True
                coords.append(((x+.5)*size,675-((y+.5)*size)))
                coords.append(((x+.5)*size,675-((y+3.5)*size)))
    for x in range(4):  ## / Diagnal
        for y in range(3):
            if board[x+y*7] != '#' and board[x+y*7]==board[x+y*7+8] and board[x+y*7]==board[x+y*7+16] and board[x+y*7]==board[x+y*7+24]:
                if rBool:
                    return True
                coords.append(((x+.5)*size,675-((y+.5)*size)))
                coords.append(((x+3.5)*size,675-((y+3.5)*size)))
    for x in range(4):  ## \ Diagnal
        for y in range(3):
            if board[x+y*7+3] != '#' and board[x+y*7+3]==board[x+y*7+9] and board[x+y*7+3]==board[x+y*7+15] and board[x+y*7+3]==board[x+y*7+21]:
                if rBool:
                    return True
                coords.append(((x+3.5)*size,675-((y+.5)*size)))
                coords.append(((x+.5)*size,675-((y+3.5)*size)))
    if rBool:
        return False
    return coords

def printBoard(Pboard,player):
    screen.fill([250, 250, 20])
    if player == 'R':
        pygame.draw.rect(screen, [200,50,0], [list(pygame.mouse.get_pos())[0]//size*size,50, size, 625])
    elif player == 'B':
        pygame.draw.rect(screen, [0,100,200], [list(pygame.mouse.get_pos())[0]//size*size,50, size, 625])
    for y in range(6):
        for x in range(7):
            drawTile(x*size,675-((y+.5)*size),Pboard[y*7+x],screen)
    if player == 'V':
        coords = (checkWin(Pboard,False))
        for i in range(len(coords)//2):
            pygame.draw.line(screen, [30,180,30], coords[2*i], coords[2*i+1], 12)
    pygame.draw.rect(screen, [255,0,0], [0,0, 625, 50])
    pygame.draw.rect(screen, [0,0,0], [0,50, 625, 5])
    pygame.display.flip()

def drawTile(x,y,tile,screen):
    if tile == '#':     #Empty Tile
        pygame.draw.circle(screen, [100,100,100], [x+size/2,y], size/2.1+2)
    elif tile == 'R':   #Red Tile
        pygame.draw.circle(screen, [0,0,0], [x+size/2,y], size/2.1+2)
        pygame.draw.circle(screen, [255,0,0], [x+size/2,y], size/2.1)
    elif tile == 'B':   #Blue Tile
        pygame.draw.circle(screen, [0,0,0], [x+size/2,y], size/2.1+2)
        pygame.draw.circle(screen, [0,0,255], [x+size/2,y], size/2.1)

def addTile(board, col, player): ## Check column and add tile if space allows
    if board[col+35]=='#':
        while board[col+35]=='#'and col>=-35:
            col-=7
        board[col+42] = player
        if player=='R':
            return board, 'B'
        return board, 'R'
    return board, player

def run():
    board = []
    pygame.display.set_mode([625,675])
    pygame.display.set_caption("Connect 4")
    player = 'R'
    for n in range(42):
        board.append('#')
    while not checkWin(board, True):
        printBoard(board,player)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.display.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = list(pygame.mouse.get_pos())
                col = int(pos[0]//size)
                if col>6:
                    col=6
                if pos[1]<50:
                    return True
                if pygame.mouse.get_pressed() == (1, 0, 0):
                    board, player = addTile(board, col, player)
    printBoard(board,'V')
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.display.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if pygame.mouse.get_pressed() == (1, 0, 0):
                    pos = list(pygame.mouse.get_pos())
                    if pos[1]<50:
                        return True
                    return False

def drawIcon(screen,x,y):
    pygame.draw.rect(screen,[250, 250, 20],[x,y,250,250])
    col = [[255,0,0],[0,0,255]]
    for n in range(5):
        for m in range(5):
            pygame.draw.circle(screen, [0,0,0], [x+25+50*n,y+25+50*m], 24)
            pygame.draw.circle(screen, col[random.randint(0,1)], [x+25+50*n,y+25+50*m], 22)
